package ir.yaddasht.app

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.*
import android.speech.RecognizerIntent
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.util.*
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Path
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.FileProvider

class MainActivity : AppCompatActivity() {
    private var darkMode = false
    private var editingNote: Note? = null
    private lateinit var blocksBox: LinearLayout
    private val store get() = NoteStore
    private lateinit var list: LinearLayout
    private var notes = mutableListOf<Note>()
    private var recorder: MediaRecorder? = null
    private var recordingPath: String? = null
    private var activeAudio: MediaPlayer? = null
    private val speechCode = 71

    override fun onCreate(savedInstanceState: Bundle?) {
        darkMode = getSharedPreferences("ui",0).getBoolean("dark",false)
        AppCompatDelegate.setDefaultNightMode(if (darkMode) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO)
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 70)
        }
        if (getSharedPreferences("security",0).contains("pin_hash")) requireUnlock() else showList()
    }

    private fun showList() {
        notes = store.loadAll(this).filter { it.deletedAt == null }.sortedWith(compareByDescending<Note> { it.pinned }.thenByDescending { it.id }).toMutableList()
                val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24,24,24,24)
            setBackgroundColor(if(darkMode) Color.rgb(28,28,30) else Color.WHITE)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val header = TextView(this).apply {
            text = "یادداشت"
            textSize = 28f
            setPadding(0,0,0,18)
        }
        root.addView(header)
        val search = EditText(this).apply {
            hint = "جستجو در یادداشت‌ها..."
            setSingleLine()
        }
        root.addView(search, LinearLayout.LayoutParams(-1, -2))
        val add = Button(this).apply { text = "＋ یادداشت جدید" }
        add.setOnClickListener { editNote(null) }
        root.addView(add)

        val tools=LinearLayout(this)
        val backup=Button(this).apply{text="☁️ پشتیبان‌گیری"}
        val restore=Button(this).apply{text="♻️ بازیابی"}
        val theme=Button(this).apply{text="🌙 حالت شب"}
        tools.addView(backup); tools.addView(restore); tools.addView(theme)
        root.addView(tools)
        val moreRow = LinearLayout(this)
        val trash = Button(this).apply { text = "🗑️ سطل زباله" }
        val lock = Button(this).apply { text = "🔐 قفل برنامه" }
        moreRow.addView(trash); moreRow.addView(lock)
        root.addView(moreRow)
        trash.setOnClickListener { showTrash() }
        lock.setOnClickListener { showLockSettings() }

        backup.setOnClickListener { exportBackup() }
        restore.setOnClickListener {
            val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="application/json"; addCategory(Intent.CATEGORY_OPENABLE)}
            startActivityForResult(i,909)
        }
        theme.setOnClickListener {
            val dark=!getSharedPreferences("ui",0).getBoolean("dark",false)
            getSharedPreferences("ui",0).edit().putBoolean("dark",dark).apply()
            recreate()
        }

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(list) }
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
        renderList("")
        search.addTextChangedListener(object: android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st:Int,c:Int,a:Int) {}
            override fun onTextChanged(s: CharSequence?, st:Int,b:Int,c:Int) { renderList(s?.toString() ?: "") }
            override fun afterTextChanged(e: android.text.Editable?) {}
        })
    }

    private fun renderList(q: String) {
        list.removeAllViews()
        notes.filter {
            q.isBlank() || it.title.contains(q,true) ||
            it.blocks.filterIsInstance<ContentBlock.Text>().any { b -> b.text.contains(q,true) }
        }.forEach { n ->
            val card = LinearLayout(this).apply {
                orientation=LinearLayout.VERTICAL
                setPadding(18,18,18,18)
                setBackgroundColor(if (darkMode) Color.rgb(48,48,52) else Color.rgb(245,245,245))
            }
            val t=TextView(this).apply { text=(if(n.pinned)"📌 " else "")+n.title.ifBlank{"بدون عنوان"}; textSize=20f; if(darkMode)setTextColor(Color.WHITE) }
            val preview=n.blocks.filterIsInstance<ContentBlock.Text>().firstOrNull()?.text.orEmpty()
            val p=TextView(this).apply { text=preview.take(100); textSize=15f; if(darkMode)setTextColor(Color.LTGRAY) }
            card.addView(t); card.addView(p)
            val row=LinearLayout(this)
            val open=Button(this).apply{text="ویرایش"}
            val pin=Button(this).apply{text=if(n.pinned)"📌 برداشتن سنجاق" else "📌 سنجاق"}
            val del=Button(this).apply{text="🗑️ سطل زباله"}
            open.setOnClickListener{editNote(n)}
            pin.setOnClickListener{
                n.pinned=!n.pinned; store.save(this,n); notes.sortWith(compareByDescending<Note>{it.pinned}.thenByDescending{it.id}); renderList(q)
            }
            del.setOnClickListener{
                n.deletedAt=System.currentTimeMillis(); store.save(this,n); notes.remove(n); renderList(q)
            }
            row.addView(open); row.addView(pin); row.addView(del); card.addView(row)
            val lp=LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,10,0,10)
            list.addView(card,lp)
        }
    }

    private fun editNote(existing: Note?) {
        editingNote = existing
        val note = existing ?: Note(System.currentTimeMillis(), "", mutableListOf(ContentBlock.Text("")), null, "یک‌بار", "شخصی")
        val root=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL; setPadding(18,18,18,18)
            layoutDirection=View.LAYOUT_DIRECTION_RTL
        }
        val title=EditText(this).apply{ hint="عنوان یادداشت"; setText(note.title); textSize=20f }
        root.addView(title)
        val category=Spinner(this)
        val cats=arrayOf("شخصی","کار","مهم")
        category.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,cats)
        category.setSelection(cats.indexOf(note.category).coerceAtLeast(0))
        root.addView(category)

        val scroll=ScrollView(this)
        blocksBox=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        scroll.addView(blocksBox)
        root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))

        fun addText(initial:String="") {
            val e=EditText(this).apply{
                hint="متن..."
                setText(initial)
                gravity=Gravity.TOP
                minLines=3
                setPadding(12,12,12,12)
            }
            blocksBox.addView(e,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,8,0,8)})
        }
        fun addImage(uri:String) {
            val img=ImageView(this).apply{
                tag=uri
                setImageURI(Uri.parse(uri)); adjustViewBounds=true; minimumHeight=180
                scaleType=ImageView.ScaleType.CENTER_CROP
                setOnClickListener{Toast.makeText(this@MainActivity,"تصویر داخل یادداشت",Toast.LENGTH_SHORT).show()}
            }
            blocksBox.addView(img,LinearLayout.LayoutParams(-1,300).apply{setMargins(0,8,0,8)})
        }
        fun addVideo(uri:String) {
            val v=VideoView(this).apply{
                tag=uri
                setVideoURI(Uri.parse(uri))
                setMediaController(android.widget.MediaController(this@MainActivity))
            }
            blocksBox.addView(v,LinearLayout.LayoutParams(-1,320).apply{setMargins(0,8,0,8)})
        }
        fun addChecklist(items: MutableList<CheckItem>) {
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; tag = items }
            items.forEach { item ->
                val cb = CheckBox(this).apply { text=item.text; isChecked=item.checked; textSize=17f }
                box.addView(cb)
            }
            val add = Button(this).apply { text="＋ افزودن مورد"; setOnClickListener { box.addView(CheckBox(this@MainActivity).apply { text="مورد جدید"; textSize=17f }) } }
            box.addView(add)
            blocksBox.addView(box, LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,8,0,8)})
        }

        fun addAudio(path:String) {
            val b=Button(this).apply{
                tag=path
                text="▶️ پخش صدای یادداشت"
                setOnClickListener{
                    try {
                        activeAudio?.release()
                        activeAudio=MediaPlayer().apply{
                            setDataSource(path); prepare(); start()
                            setOnCompletionListener{release()}
                        }
                    } catch(e:Exception){Toast.makeText(this@MainActivity,"فایل صوتی پیدا نشد",Toast.LENGTH_SHORT).show()}
                }
            }
            blocksBox.addView(b)
        }

        fun addDrawing(path:String) {
            val img=ImageView(this).apply {
                tag=path
                setImageURI(Uri.fromFile(File(path)))
                adjustViewBounds=true
                minimumHeight=220
                scaleType=ImageView.ScaleType.FIT_CENTER
                setPadding(4,4,4,4)
            }
            blocksBox.addView(img,LinearLayout.LayoutParams(-1,300).apply{setMargins(0,8,0,8)})
        }

        fun addMap(map: ContentBlock.MapBlock) {
            val web=android.webkit.WebView(this).apply {
                tag=map
                settings.javaScriptEnabled=true
                settings.domStorageEnabled=true
                settings.loadWithOverviewMode=true
                settings.useWideViewPort=true
            }
            val lat=map.latitude; val lon=map.longitude
            val label=android.text.TextUtils.htmlEncode(map.label)
            val html="""
                <!doctype html><html><head><meta name=viewport content="width=device-width,initial-scale=1">
                <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
                <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
                <style>html,body,#map{height:100%;margin:0} .label{font-family:sans-serif;direction:rtl}</style></head>
                <body><div id=map></div><script>
                var m=L.map('map').setView([$lat,$lon],15);
                L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap'}).addTo(m);
                L.marker([$lat,$lon]).addTo(m).bindPopup('<span class=label>$label</span>').openPopup();
                </script></body></html>
            """.trimIndent()
            web.loadDataWithBaseURL("https://www.openstreetmap.org/",html,"text/html","UTF-8",null)
            blocksBox.addView(web,LinearLayout.LayoutParams(-1,360).apply{setMargins(0,8,0,8)})
        }

        note.blocks.forEach { b ->
            when(b){
                is ContentBlock.Text -> addText(b.text)
                is ContentBlock.Image -> addImage(b.uri)
                is ContentBlock.Video -> addVideo(b.uri)
                is ContentBlock.Audio -> addAudio(b.path)
                is ContentBlock.Checklist -> addChecklist(b.items)
                is ContentBlock.Drawing -> addDrawing(b.path)
                is ContentBlock.MapBlock -> addMap(b)
            }
        }

        // Attach pending media/audio (useful after Android's document/speech pickers return).
        val pendingM=getSharedPreferences("pending_media",0)
        val pendingType=pendingM.getString("type",null)
        val pendingUri=pendingM.getString("uri",null)
        if(pendingType!=null && pendingUri!=null) {
            if(pendingType=="image") addImage(pendingUri) else if(pendingType=="video") addVideo(pendingUri)
            pendingM.edit().clear().apply()
        }
        val pendingA=getSharedPreferences("pending_audio",0).getString("path",null)
        if(pendingA!=null) {
            addAudio(pendingA)
            getSharedPreferences("pending_audio",0).edit().clear().apply()
        }

        val controls=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val mediaRow=LinearLayout(this)
        val img=Button(this).apply{text="🖼️ افزودن عکس"}
        val vid=Button(this).apply{text="🎬 افزودن فیلم"}
        val speech=Button(this).apply{text="🗣️ تبدیل صدا به متن"}
        val checklist=Button(this).apply{text="☑️ افزودن چک‌لیست"}
        val drawing=Button(this).apply{text="🎨 طراحی و نمادها"}
        val map=Button(this).apply{text="🗺️ افزودن نقشه"}
        mediaRow.addView(img); mediaRow.addView(vid); controls.addView(mediaRow)
        controls.addView(speech); controls.addView(checklist); controls.addView(drawing); controls.addView(map)

        val record=Button(this).apply{text="🎙️ ضبط صدای جدید"}
        val share=Button(this).apply{text="📤 انتقال برای دیگران"}
        val print=Button(this).apply{text="🖨️ چاپ یادداشت"}
        val pdf=Button(this).apply{text="📄 ساخت PDF و ارسال"}
        val save=Button(this).apply{text="💾 ذخیره یادداشت"}
        controls.addView(record); controls.addView(share); controls.addView(print); controls.addView(pdf); controls.addView(save)
        root.addView(controls)
        setContentView(root)

        img.setOnClickListener{
            val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{
                type="image/*"; addCategory(Intent.CATEGORY_OPENABLE); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }
            startActivityForResult(i,101)
        }
        vid.setOnClickListener{
            val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{
                type="video/*"; addCategory(Intent.CATEGORY_OPENABLE); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }
            startActivityForResult(i,102)
        }
        checklist.setOnClickListener{
            addChecklist(mutableListOf(CheckItem("مورد جدید")))
        }
        drawing.setOnClickListener { showDrawingEditor { path -> addDrawing(path) } }
        map.setOnClickListener { showMapDialog { m -> addMap(m) } }
        speech.setOnClickListener{
            val i=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{
                putExtra(RecognizerIntent.EXTRA_LANGUAGE,"fa-IR")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE,"fa-IR")
                putExtra(RecognizerIntent.EXTRA_PROMPT,"صحبت کنید")
            }
            try{startActivityForResult(i,speechCode)}catch(_:Exception){Toast.makeText(this,"تشخیص گفتار روی این گوشی در دسترس نیست",Toast.LENGTH_SHORT).show()}
        }
        record.setOnClickListener{
            if(recorder==null) startRecording(note.id, record) else stopRecording(record)
        }
        share.setOnClickListener{
            val text = buildTextFromEditor(blocksBox, title.text.toString(), category.selectedItem?.toString() ?: "")
            val intent = Intent(Intent.ACTION_SEND).apply{
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, title.text.toString().ifBlank { "یادداشت" })
                putExtra(Intent.EXTRA_TEXT, text)
            }
            startActivity(Intent.createChooser(intent, "ارسال یادداشت با..."))
        }
        print.setOnClickListener{
            val text = buildTextFromEditor(blocksBox, title.text.toString(), category.selectedItem?.toString() ?: "")
            printNote(title.text.toString().ifBlank { "یادداشت" }, text)
        }
        pdf.setOnClickListener{
            val pdfTitle = title.text.toString().ifBlank { "یادداشت" }
            val text = buildTextFromEditor(blocksBox, pdfTitle, category.selectedItem?.toString() ?: "")
            createAndSharePdf(pdfTitle, text)
        }
        save.setOnClickListener{
            note.title=title.text.toString()
            note.category=category.selectedItem.toString()
            note.blocks.clear()
            for(i in 0 until blocksBox.childCount){
                when(val v=blocksBox.getChildAt(i)){
                    is EditText -> note.blocks.add(ContentBlock.Text(v.text.toString()))
                    is CheckBox -> note.blocks.add(ContentBlock.Text(if(v.isChecked) "☑ ${v.text}" else "☐ ${v.text}"))
                    is ImageView -> {
                        val path=v.tag as? String
                        if(path!=null) {
                            if(path.endsWith(".png", true) && File(path).parentFile?.name == "drawings") note.blocks.add(ContentBlock.Drawing(path))
                            else note.blocks.add(ContentBlock.Image(path))
                        }
                    }
                    is android.webkit.WebView -> {
                        val m=v.tag as? ContentBlock.MapBlock
                        if(m!=null) note.blocks.add(m)
                    }
                    is VideoView -> {
                        val uri=v.tag as? String
                        if(uri!=null) note.blocks.add(ContentBlock.Video(uri))
                    }
                    is LinearLayout -> {
                        val items = mutableListOf<CheckItem>()
                        for (j in 0 until v.childCount) {
                            val child=v.getChildAt(j)
                            if (child is CheckBox) items.add(CheckItem(child.text.toString(), child.isChecked))
                        }
                        if(items.isNotEmpty()) note.blocks.add(ContentBlock.Checklist(items))
                    }
                    is Button -> {
                        val path=v.tag as? String
                        if(path!=null) note.blocks.add(ContentBlock.Audio(path))
                    }
                }
            }
            store.save(this,note)
            Toast.makeText(this,"یادداشت ذخیره شد",Toast.LENGTH_SHORT).show()
            showList()
        }


    }

    private fun showMapDialog(onAdd: (ContentBlock.MapBlock) -> Unit) {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,8,24,8);layoutDirection=View.LAYOUT_DIRECTION_RTL}
        val label=EditText(this).apply{hint="نام مکان (اختیاری)"}
        val lat=EditText(this).apply{hint="عرض جغرافیایی مثال: 52.3676";inputType=android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL or android.text.InputType.TYPE_NUMBER_FLAG_SIGNED}
        val lon=EditText(this).apply{hint="طول جغرافیایی مثال: 4.9041";inputType=android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL or android.text.InputType.TYPE_NUMBER_FLAG_SIGNED}
        box.addView(label);box.addView(lat);box.addView(lon)
        AlertDialog.Builder(this).setTitle("🗺️ افزودن نقشه").setMessage("مختصات را وارد کنید. نقشه داخل خود یادداشت نمایش داده می‌شود.").setView(box).setPositiveButton("افزودن"){_,_->
            val la=lat.text.toString().replace(",",".").toDoubleOrNull(); val lo=lon.text.toString().replace(",",".").toDoubleOrNull()
            if(la==null||lo==null||la !in -90.0..90.0||lo !in -180.0..180.0){Toast.makeText(this,"مختصات نامعتبر است",Toast.LENGTH_SHORT).show();return@setPositiveButton}
            onAdd(ContentBlock.MapBlock(la,lo,label.text.toString()))
        }.setNegativeButton("انصراف",null).show()
    }

    private fun showDrawingEditor(onAdd: (String) -> Unit) {
        val draw=SketchView(this)
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(8,8,8,8);layoutDirection=View.LAYOUT_DIRECTION_RTL}
        root.addView(draw,LinearLayout.LayoutParams(-1,0,1f))
        val tools=LinearLayout(this)
        fun sym(s:String)=Button(this).apply{text=s;setOnClickListener{draw.addSymbol(s)}}
        tools.addView(Button(this).apply{text="↩️";setOnClickListener{draw.undo()}})
        tools.addView(Button(this).apply{text="🧹";setOnClickListener{draw.clear()}})
        listOf("→","←","↔","✓","✗","○","□","△","◇","★","+","−","×","÷","⚠").forEach{tools.addView(sym(it))}
        root.addView(ScrollView(this).apply{addView(tools)},LinearLayout.LayoutParams(-1,64))
        AlertDialog.Builder(this).setTitle("🎨 طراحی و نمادها").setView(root).setPositiveButton("💾 افزودن به یادداشت"){_,_->
            val dir=File(filesDir,"drawings");dir.mkdirs(); val file=File(dir,"drawing_${System.currentTimeMillis()}.png")
            try{draw.save(file);onAdd(file.absolutePath)}catch(e:Exception){Toast.makeText(this,"ذخیره طرح انجام نشد",Toast.LENGTH_SHORT).show()}
        }.setNegativeButton("انصراف",null).show()
    }

    private class SketchView(context: Context): View(context) {
        private val paths=mutableListOf<Pair<Path,Paint>>(); private val undone=mutableListOf<Pair<Path,Paint>>(); private var current:Path?=null
        private val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.BLACK;style=Paint.Style.STROKE;strokeWidth=7f;strokeCap=Paint.Cap.ROUND}
        private val symbols=mutableListOf<Pair<String,FloatArray>>()
        init{setBackgroundColor(Color.WHITE)}
        override fun onDraw(c:Canvas){super.onDraw(c);paths.forEach{c.drawPath(it.first,it.second)};symbols.forEach{(s,p)->val tp=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.BLACK;textSize=72f;style=Paint.Style.FILL};c.drawText(s,p[0],p[1],tp)} }
        override fun onTouchEvent(e:android.view.MotionEvent):Boolean{when(e.action){MotionEvent.ACTION_DOWN->{current=Path().apply{moveTo(e.x,e.y)};paths.add(current!! to Paint(paint));undone.clear();invalidate();return true};MotionEvent.ACTION_MOVE->{current?.lineTo(e.x,e.y);invalidate();return true};MotionEvent.ACTION_UP->{current=null;return true}};return true}
        fun undo(){if(paths.isNotEmpty())undone.add(paths.removeAt(paths.lastIndex));invalidate()}
        fun clear(){paths.clear();symbols.clear();undone.clear();invalidate()}
        fun addSymbol(s:String){symbols.add(s to floatArrayOf(width/2f,height/2f));invalidate()}
        fun save(file:File){val b=Bitmap.createBitmap(width.coerceAtLeast(1),height.coerceAtLeast(1),Bitmap.Config.ARGB_8888);val c=Canvas(b);c.drawColor(Color.WHITE);draw(c);file.outputStream().use{b.compress(Bitmap.CompressFormat.PNG,100,it)};b.recycle()}
    }

    private fun buildTextFromEditor(box: LinearLayout, title: String, category: String): String {
        val sb = StringBuilder()
        sb.append(title.ifBlank { "یادداشت" }).append("\n")
        if (category.isNotBlank()) sb.append("دسته‌بندی: ").append(category).append("\n")
        sb.append("\n")
        for (i in 0 until box.childCount) {
            when (val v = box.getChildAt(i)) {
                is EditText -> if (v.text.isNotBlank()) sb.append(v.text).append("\n\n")
                is ImageView -> {
                    val path=v.tag as? String
                    sb.append(if(path?.endsWith(".png", true)==true && File(path).parentFile?.name=="drawings") "[طرح دستی پیوست شده]" else "[عکس پیوست شده]").append("\n\n")
                }
                is VideoView -> sb.append("[فیلم پیوست شده]\n\n")
                is android.webkit.WebView -> {
                    val m=v.tag as? ContentBlock.MapBlock
                    if(m!=null) sb.append("[نقشه: ").append(m.label.ifBlank { "موقعیت ذخیره‌شده" }).append(" — ").append(m.latitude).append(", ").append(m.longitude).append("]\n\n")
                }
                is Button -> if (v.tag is String) sb.append("[فایل صوتی پیوست شده]\n\n")
                is LinearLayout -> for (j in 0 until v.childCount) { val c=v.getChildAt(j); if(c is CheckBox) sb.append(if(c.isChecked) "☑ " else "☐ ").append(c.text).append("\n") }
            }
        }
        return sb.toString().trim()
    }

    private fun buildNoteText(note: Note, title: String, category: String): String {
        val sb = StringBuilder()
        sb.append(title.ifBlank { "یادداشت" }).append("\n")
        if (category.isNotBlank()) sb.append("دسته‌بندی: ").append(category).append("\n")
        sb.append("\n")
        note.blocks.forEach { block ->
            when (block) {
                is ContentBlock.Text -> if (block.text.isNotBlank()) sb.append(block.text).append("\n\n")
                is ContentBlock.Image -> sb.append("[عکس پیوست شده]\n\n")
                is ContentBlock.Video -> sb.append("[فیلم پیوست شده]\n\n")
                is ContentBlock.Audio -> sb.append("[فایل صوتی پیوست شده]\n\n")
                is ContentBlock.Checklist -> block.items.forEach { item -> sb.append(if(item.checked) "☑ " else "☐ ").append(item.text).append("\n") }
                is ContentBlock.Drawing -> sb.append("[طرح دستی پیوست شده]\n\n")
                is ContentBlock.MapBlock -> sb.append("[نقشه: ").append(block.label.ifBlank { "موقعیت ذخیره‌شده" }).append(" — ").append(block.latitude).append(", ").append(block.longitude).append("]\n\n")
            }
        }
        return sb.toString().trim()
    }

    private fun exportBackup() {
        try {
            val dir=File(cacheDir,"backup"); dir.mkdirs()
            val file=File(dir,"yaddasht-backup-${System.currentTimeMillis()}.json")
            file.writeText(NoteStore.exportJson(this), Charsets.UTF_8)
            val uri=FileProvider.getUriForFile(this,"${packageName}.fileprovider",file)
            val send=Intent(Intent.ACTION_SEND).apply {
                type="application/json"
                putExtra(Intent.EXTRA_SUBJECT,"پشتیبان یادداشت‌ها")
                putExtra(Intent.EXTRA_STREAM,uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(send,"ذخیره یا ارسال پشتیبان"))
        } catch(e:Exception) {
            Toast.makeText(this,"ساخت پشتیبان انجام نشد",Toast.LENGTH_SHORT).show()
        }
    }

    private fun printNote(title: String, text: String) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.KITKAT) {
            Toast.makeText(this, "قابلیت چاپ به نسخه جدیدتر اندروید نیاز دارد", Toast.LENGTH_SHORT).show()
            return
        }
        val printManager = getSystemService(Context.PRINT_SERVICE) as android.print.PrintManager
        val webView = android.webkit.WebView(this)
        webView.settings.defaultTextEncodingName = "UTF-8"
        val escaped = android.text.TextUtils.htmlEncode(text).replace("\n", "<br>")
        val html = """
            <html><head><meta charset="utf-8"><style>
            body{font-family:sans-serif;direction:rtl;text-align:right;padding:24px;font-size:16px;line-height:1.8}
            h1{font-size:24px}
            </style></head><body><h1>${android.text.TextUtils.htmlEncode(title)}</h1><p>$escaped</p></body></html>
        """.trimIndent()
        webView.webViewClient = object : android.webkit.WebViewClient() {
            override fun onPageFinished(view: android.webkit.WebView?, url: String?) {
                val adapter = webView.createPrintDocumentAdapter("یادداشت - $title")
                printManager.print(
                    "یادداشت - $title",
                    adapter,
                    android.print.PrintAttributes.Builder()
                        .setMediaSize(android.print.PrintAttributes.MediaSize.ISO_A4)
                        .setMinMargins(android.print.PrintAttributes.Margins.NO_MARGINS)
                        .build()
                )
            }
        }
        webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
    }

    private fun createAndSharePdf(title: String, text: String) {
        try {
            val dir = File(cacheDir, "pdf")
            dir.mkdirs()
            val safe = title.replace(Regex("[^\\p{L}\\p{N}_-]+"), "_").take(40).ifBlank { "yaddasht" }
            val file = File(dir, "$safe-${System.currentTimeMillis()}.pdf")

            val document = PdfDocument()
            val pageWidth = 595
            val pageHeight = 842
            val margin = 42
            val textWidth = pageWidth - margin * 2

            val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = 14f
                typeface = Typeface.create("sans", Typeface.NORMAL)
                color = android.graphics.Color.BLACK
            }
            val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = 22f
                typeface = Typeface.create("sans", Typeface.BOLD)
                color = android.graphics.Color.BLACK
            }

            val titleLayout = StaticLayout.Builder.obtain(
                title, 0, title.length, titlePaint, textWidth
            ).setAlignment(Layout.Alignment.ALIGN_NORMAL)
             .setIncludePad(true)
             .setTextDirection(android.text.TextDirectionHeuristics.FIRSTSTRONG_RTL)
             .build()

            val body = text.removePrefix(title).trim().ifBlank { "محتوایی برای نمایش وجود ندارد." }
            val bodyLayout = StaticLayout.Builder.obtain(
                body, 0, body.length, paint, textWidth
            ).setAlignment(Layout.Alignment.ALIGN_NORMAL)
             .setIncludePad(true)
             .setTextDirection(android.text.TextDirectionHeuristics.FIRSTSTRONG_RTL)
             .build()

            var bodyOffset = 0
            var pageNumber = 1
            while (bodyOffset < bodyLayout.lineCount || pageNumber == 1) {
                val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
                val page = document.startPage(pageInfo)
                val canvas = page.canvas
                canvas.drawColor(android.graphics.Color.WHITE)

                canvas.save()
                canvas.translate(margin.toFloat(), margin.toFloat())
                if (pageNumber == 1) {
                    titleLayout.draw(canvas)
                    canvas.translate(0f, (titleLayout.height + 18).toFloat())
                }

                val available = pageHeight - margin * 2 - (if (pageNumber == 1) titleLayout.height + 18 else 0)
                val startLine = bodyLayout.getLineForOffset(bodyOffset)
                var endLine = startLine
                var used = 0
                while (endLine < bodyLayout.lineCount) {
                    val h = bodyLayout.getLineBottom(endLine) - bodyLayout.getLineTop(endLine)
                    if (used + h > available) break
                    used += h
                    endLine++
                }
                if (endLine == startLine) endLine = (startLine + 1).coerceAtMost(bodyLayout.lineCount)
                val endOffset = bodyLayout.getLineEnd(endLine - 1).coerceAtLeast(bodyOffset)

                canvas.save()
                canvas.clipRect(0, 0, textWidth, available)
                canvas.translate(0f, -bodyLayout.getLineTop(startLine).toFloat())
                bodyLayout.draw(canvas)
                canvas.restore()
                canvas.restore()

                document.finishPage(page)
                bodyOffset = endOffset
                pageNumber++
                if (bodyOffset >= bodyLayout.text.length) break
            }

            file.outputStream().use { document.writeTo(it) }
            document.close()

            val uri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", file)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_SUBJECT, title)
                putExtra(Intent.EXTRA_TEXT, "فایل PDF یادداشت: $title")
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(send, "ارسال PDF با..."))
        } catch (e: Exception) {
            Toast.makeText(this, "ساخت PDF انجام نشد: ${e.message ?: "خطای ناشناخته"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun startRecording(noteId:Long, button:Button){
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.RECORD_AUDIO),73); return
        }
        val dir=File(filesDir,"audio"); dir.mkdirs()
        recordingPath=File(dir,"note_${noteId}_${System.currentTimeMillis()}.m4a").absolutePath
        recorder=MediaRecorder(this).apply{
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setOutputFile(recordingPath)
            prepare(); start()
        }
        button.text="⏹️ توقف ضبط"
        Toast.makeText(this,"در حال ضبط صدا...",Toast.LENGTH_SHORT).show()
    }
    private fun stopRecording(button:Button){
        try{recorder?.stop()}catch(_:Exception){}
        recorder?.release(); recorder=null
        val path=recordingPath
        if(path!=null){
            // add to current editor by placing a button at the end is handled through a lightweight event.
            Toast.makeText(this,"ضبط صدا انجام شد؛ هنگام ذخیره به یادداشت اضافه می‌شود.",Toast.LENGTH_SHORT).show()
            val current=NoteStore.loadAll(this).firstOrNull { path.contains("note_${it.id}_") }
            // For new notes, persist the audio as a standalone attachment marker in a tiny preference.
            getSharedPreferences("pending_audio",0).edit().putString("path",path).apply()
        }
        button.text="🎙️ ضبط صدای جدید"
    }

    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){
        super.onActivityResult(requestCode,resultCode,data)
        if(resultCode != RESULT_OK) return

        if(requestCode == speechCode) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if(!spoken.isNullOrBlank()) {
                val target = findFocusedEditText(window.decorView)
                if(target != null) {
                    val pos = target.selectionStart.coerceAtLeast(0)
                    target.text.insert(pos, spoken + " ")
                }
            }
            return
        }

        val uri=data?.data ?: return
        if(requestCode==909){
            try { val json=contentResolver.openInputStream(uri)?.bufferedReader()?.use{it.readText()} ?: ""; val count=store.importJson(this,json); Toast.makeText(this,"$count یادداشت بازیابی شد",Toast.LENGTH_LONG).show(); showList() } catch(e:Exception){Toast.makeText(this,"فایل پشتیبان نامعتبر است",Toast.LENGTH_LONG).show()}
            return
        }
        try{contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)}catch(_:Exception){}
        getSharedPreferences("pending_media",0).edit()
            .putString("type", if(requestCode==101)"image" else "video")
            .putString("uri",uri.toString()).apply()
        Toast.makeText(this,if(requestCode==101)"عکس انتخاب شد؛ دوباره وارد ویرایش یادداشت شو تا داخل آن قرار بگیرد." else "فیلم انتخاب شد؛ دوباره وارد ویرایش یادداشت شو تا داخل آن قرار بگیرد.",Toast.LENGTH_SHORT).show()
    }

    private fun showTrash() {
        val deleted = store.loadAll(this, true).filter { it.deletedAt != null }.sortedByDescending { it.deletedAt }
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,18,18,18);layoutDirection=View.LAYOUT_DIRECTION_RTL}
        box.addView(TextView(this).apply{text="🗑️ سطل زباله";textSize=26f})
        if(deleted.isEmpty()) box.addView(TextView(this).apply{text="سطل زباله خالی است.";textSize=18f})
        deleted.forEach { n ->
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
            row.addView(TextView(this).apply{text=n.title.ifBlank{"بدون عنوان"};textSize=17f},LinearLayout.LayoutParams(0,-2,1f))
            row.addView(Button(this).apply{text="♻️ بازیابی";setOnClickListener{n.deletedAt=null;store.save(this@MainActivity,n);showTrash()}})
            row.addView(Button(this).apply{text="حذف دائم";setOnClickListener{store.delete(this@MainActivity,n.id);showTrash()}})
            box.addView(row)
        }
        box.addView(Button(this).apply{text="بازگشت";setOnClickListener{showList()}})
        setContentView(ScrollView(this).apply{addView(box)})
    }

    private fun showLockSettings() {
        val prefs=getSharedPreferences("security",0)
        val has=prefs.contains("pin_hash")
        val input=EditText(this).apply{inputType=2;hint="رمز ۴ رقمی یا بیشتر"}
        AlertDialog.Builder(this).setTitle(if(has) "تغییر/لغو قفل" else "قفل برنامه")
            .setView(input).setPositiveButton(if(has) "ذخیره") { _,_->
                val pin=input.text.toString()
                if(pin.length>=4) prefs.edit().putString("pin_hash",sha256(pin)).apply() else if(has && pin.isBlank()) prefs.edit().remove("pin_hash").apply()
            }.setNegativeButton("انصراف",null).show()
    }

    private fun sha256(value:String):String {
        val d=java.security.MessageDigest.getInstance("SHA-256").digest(value.toByteArray(Charsets.UTF_8))
        return d.joinToString(""){"%02x".format(it)}
    }

    private fun requireUnlock():Boolean {
        val hash=getSharedPreferences("security",0).getString("pin_hash",null) ?: return true
        val input=EditText(this).apply{inputType=2;hint="رمز قفل"}
        var dialog:AlertDialog?=null
        dialog=AlertDialog.Builder(this).setTitle("🔐 قفل برنامه").setView(input).setCancelable(false)
            .setPositiveButton("ورود",null).create()
        dialog.setOnShowListener { dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener { if(sha256(input.text.toString())==hash) { dialog.dismiss(); showList() } else input.error="رمز اشتباه است" } }
        dialog.show(); return false
    }

    private fun findFocusedEditText(view: View): EditText? {
        if(view is EditText && view.hasFocus()) return view
        if(view is ViewGroup) {
            for(i in 0 until view.childCount) {
                val found = findFocusedEditText(view.getChildAt(i))
                if(found != null) return found
            }
        }
        return null
    }
}
