package ir.yaddasht.app

data class Note(
    val id: Long,
    var title: String,
    var blocks: MutableList<ContentBlock>,
    var reminder: Long?,
    var repeat: String,
    var category: String,
    var pinned: Boolean = false,
    var deletedAt: Long? = null
)

sealed class ContentBlock {
    data class Text(var text: String) : ContentBlock()
    data class Image(val uri: String) : ContentBlock()
    data class Video(val uri: String) : ContentBlock()
    data class Audio(val path: String) : ContentBlock()
    data class Checklist(var items: MutableList<CheckItem>) : ContentBlock()
    data class Drawing(val path: String) : ContentBlock()
    data class MapBlock(val latitude: Double, val longitude: Double, val label: String = "") : ContentBlock()
}

data class CheckItem(var text: String, var checked: Boolean = false)
