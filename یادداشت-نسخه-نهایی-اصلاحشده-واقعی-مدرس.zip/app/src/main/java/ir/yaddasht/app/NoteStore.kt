package ir.yaddasht.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object NoteStore {
    private const val PREF = "notes_v9"

    fun save(context: Context, note: Note) {
        val p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        p.edit().putString("note_${note.id}", encode(note).toString()).apply()
    }

    fun delete(context: Context, id: Long) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().remove("note_$id").apply()
    }

    fun loadAll(context: Context, includeTrash: Boolean = false): MutableList<Note> {
        val p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val out = mutableListOf<Note>()
        p.all.forEach { (key, value) ->
            if (!key.startsWith("note_") || value !is String) return@forEach
            try {
                val n = decode(JSONObject(value))
                if (includeTrash || n.deletedAt == null) out.add(n)
            } catch (_: Exception) {}
        }
        return out.sortedWith(compareByDescending<Note> { it.pinned }.thenByDescending { it.id }).toMutableList()
    }

    fun exportJson(context: Context): String {
        val a = JSONArray()
        loadAll(context, true).forEach { a.put(encode(it)) }
        return a.toString()
    }

    fun importJson(context: Context, json: String): Int {
        val a = JSONArray(json)
        var count = 0
        for (i in 0 until a.length()) {
            save(context, decode(a.getJSONObject(i)))
            count++
        }
        return count
    }

    private fun encode(note: Note): JSONObject {
        val o = JSONObject()
        o.put("id", note.id).put("title", note.title)
            .put("reminder", note.reminder ?: JSONObject.NULL)
            .put("repeat", note.repeat).put("category", note.category)
            .put("pinned", note.pinned).put("deletedAt", note.deletedAt ?: JSONObject.NULL)
        val a = JSONArray()
        note.blocks.forEach { b ->
            val x = JSONObject()
            when (b) {
                is ContentBlock.Text -> x.put("type", "text").put("text", b.text)
                is ContentBlock.Image -> x.put("type", "image").put("uri", b.uri)
                is ContentBlock.Video -> x.put("type", "video").put("uri", b.uri)
                is ContentBlock.Audio -> x.put("type", "audio").put("path", b.path)
                is ContentBlock.Pdf -> x.put("type", "pdf").put("uri", b.uri).put("name", b.name)
                is ContentBlock.Drawing -> x.put("type", "drawing").put("path", b.path)
                is ContentBlock.MapBlock -> x.put("type", "map").put("latitude", b.latitude).put("longitude", b.longitude).put("label", b.label)
                is ContentBlock.Checklist -> {
                    x.put("type", "checklist")
                    val items = JSONArray()
                    b.items.forEach { item -> items.put(JSONObject().put("text", item.text).put("checked", item.checked)) }
                    x.put("items", items)
                }
            }
            a.put(x)
        }
        return o.put("blocks", a)
    }

    private fun decode(o: JSONObject): Note {
        val blocks = mutableListOf<ContentBlock>()
        val a = o.optJSONArray("blocks") ?: JSONArray()
        for (i in 0 until a.length()) {
            val x = a.getJSONObject(i)
            when (x.optString("type")) {
                "text" -> blocks.add(ContentBlock.Text(x.optString("text")))
                "image" -> blocks.add(ContentBlock.Image(x.optString("uri")))
                "video" -> blocks.add(ContentBlock.Video(x.optString("uri")))
                "audio" -> blocks.add(ContentBlock.Audio(x.optString("path")))
                "pdf" -> blocks.add(ContentBlock.Pdf(x.optString("uri"), x.optString("name", "فایل PDF")))
                "drawing" -> blocks.add(ContentBlock.Drawing(x.optString("path")))
                "map" -> blocks.add(ContentBlock.MapBlock(x.optDouble("latitude", 0.0), x.optDouble("longitude", 0.0), x.optString("label")))
                "checklist" -> {
                    val items = mutableListOf<CheckItem>()
                    val ia = x.optJSONArray("items") ?: JSONArray()
                    for (j in 0 until ia.length()) {
                        val it = ia.getJSONObject(j)
                        items.add(CheckItem(it.optString("text"), it.optBoolean("checked")))
                    }
                    blocks.add(ContentBlock.Checklist(items))
                }
            }
        }
        return Note(
            o.getLong("id"), o.optString("title"), blocks,
            if (o.isNull("reminder")) null else o.optLong("reminder"),
            o.optString("repeat"), o.optString("category"),
            o.optBoolean("pinned", false),
            if (o.isNull("deletedAt")) null else o.optLong("deletedAt")
        )
    }
}
