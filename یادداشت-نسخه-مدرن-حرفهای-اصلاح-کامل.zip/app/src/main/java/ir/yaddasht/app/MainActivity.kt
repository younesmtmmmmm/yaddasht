package ir.yaddasht.app

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.*
import android.speech.RecognizerIntent
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.util.*
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Path
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.FileProvider
import com.google.android.material.card.MaterialCardView
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.textfield.TextInputLayout
import com.google.android.material.textfield.TextInputEditText

class MainActivity : AppCompatActivity() {
    private var darkMode = false
    private var editingNote: Note? = null
    private lateinit var blocksBox: LinearLayout
    private val store get() = NoteStore
    private lateinit var list: LinearLayout
    private var notes = mutableListOf<Note>()
    private var recorder: MediaRecorder? = null
    private var recordingPath: String? = null
    private var activeAudio: MediaPlayer? = null
    private val speechCode = 71

    override fun onCreate(savedInstanceState: Bundle?) {
        darkMode = getSharedPreferences("ui",0).getBoolean("dark",false)
        AppCompatDelegate.setDefaultNightMode(if (darkMode) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO)
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 70)
        }
        if (getSharedPreferences("security",0).contains("pin_hash")) requireUnlock() else showList()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(bg: Int, radius: Float = 18f, stroke: Int? = null): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply {
            setColor(bg)
            cornerRadius = dp(radius.toInt()).toFloat()
            if (stroke != null) setStroke(dp(1), stroke)
        }

    private fun showList() {
        notes = store.loadAll(this).filter { it.deletedAt == null }
            .sortedWith(compareByDescending<Note> { it.pinned }.thenByDescending { it.id }).toMutableList()

        val bg = if (darkMode) Color.rgb(12, 16, 25) else Color.rgb(246, 247, 251)
        val surface = if (darkMode) Color.rgb(24, 29, 42) else Color.WHITE
        val surface2 = if (darkMode) Color.rgb(31, 37, 53) else Color.rgb(238, 241, 248)
        val textColor = if (darkMode) Color.rgb(245,247,252) else Color.rgb(25,32,52)
        val subColor = if (darkMode) Color.rgb(166,176,197) else Color.rgb(104,114,136)
        val primary = Color.rgb(92, 78, 220)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            fitsSystemWindows = true
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(18), dp(18), dp(8))
        }
        val menu = TextView(this).apply { text="☰"; textSize=23f; gravity=Gravity.CENTER; setTextColor(textColor) }
        menu.setOnClickListener { showSettingsMenu() }
        top.addView(menu, LinearLayout.LayoutParams(dp(46),dp(46)))
        val titleBox=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER}
        titleBox.addView(TextView(this).apply{text="یادداشت";textSize=26f;typeface=Typeface.DEFAULT_BOLD;setTextColor(textColor);gravity=Gravity.CENTER})
        titleBox.addView(TextView(this).apply{text="همه چیز، مرتب و همیشه در دسترس";textSize=12f;setTextColor(subColor);gravity=Gravity.CENTER})
        top.addView(titleBox,LinearLayout.LayoutParams(0,-2,1f))
        val settings=TextView(this).apply{text="⚙";textSize=23f;gravity=Gravity.CENTER;setTextColor(textColor)}
        settings.setOnClickListener{showSettingsMenu()}
        top.addView(settings,LinearLayout.LayoutParams(dp(46),dp(46)))
        root.addView(top)

        val searchBox=TextInputLayout(this).apply{
            hint="جستجوی یادداشت‌ها"; boxBackgroundMode=TextInputLayout.BOX_BACKGROUND_FILLED
            boxBackgroundColor=surface2; boxCornerRadiusTopStart=dp(18).toFloat();boxCornerRadiusTopEnd=dp(18).toFloat();boxCornerRadiusBottomStart=dp(18).toFloat();boxCornerRadiusBottomEnd=dp(18).toFloat()
            setBoxStrokeColor(Color.TRANSPARENT)
            setStartIconDrawable(android.R.drawable.ic_menu_search)
        }
        val search=TextInputEditText(this).apply{isSingleLine=true;textSize=14f;setTextColor(textColor);setHintTextColor(subColor);setPadding(dp(8),0,dp(8),0)}
        searchBox.addView(search,TextInputLayout.LayoutParams(-1,dp(52)))
        root.addView(searchBox,LinearLayout.LayoutParams(-1,dp(60)).apply{setMargins(dp(18),dp(4),dp(18),dp(6))})

        val chips=ChipGroup(this).apply{isSingleLine=true;chipSpacingHorizontal=dp(6);layoutDirection=View.LAYOUT_DIRECTION_RTL;setPadding(dp(16),0,dp(16),0)}
        val categories=listOf("همه","کلاس","دانشگاه","کار","شخصی","فایل‌ها")
        categories.forEachIndexed{idx,cat->
            val chip=Chip(this).apply{text=cat;isCheckable=true;isChecked=idx==0;textSize=12f;setTextColor(if(idx==0)Color.WHITE else textColor);setChipBackgroundColorResource(android.R.color.transparent)}
            chip.chipBackgroundColor=android.content.res.ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked),intArrayOf()),intArrayOf(primary,surface))
            chip.setOnCheckedChangeListener{_,checked->if(checked){for(i in 0 until chips.childCount){val c=chips.getChildAt(i) as Chip;if(c!=chip)c.isChecked=false};renderList(search.text?.toString()?: "",cat)}}
            chips.addView(chip)
        }
        root.addView(chips,LinearLayout.LayoutParams(-1,dp(50)))

        list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(4),dp(14),dp(100))}
        val scroll=ScrollView(this).apply{addView(list);clipToPadding=false}
        root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))

        val bottom=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER;setPadding(dp(10),dp(5),dp(10),dp(8));background=surface;layoutDirection=View.LAYOUT_DIRECTION_RTL;elevation=dp(12).toFloat()}
        fun nav(label:String,icon:String,active:Boolean,action:()->Unit):LinearLayout{
            val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setOnClickListener{action()}}
            val ic=TextView(this).apply{text=icon;textSize=21f;gravity=Gravity.CENTER;setTextColor(if(active)primary else subColor)}
            val tx=TextView(this).apply{text=label;textSize=11f;gravity=Gravity.CENTER;setTextColor(if(active)primary else subColor);setTypeface(null,if(active)Typeface.BOLD else Typeface.NORMAL)}
            box.addView(ic);box.addView(tx);return box
        }
        bottom.addView(nav("یادداشت‌ها","▤",true){},LinearLayout.LayoutParams(0,dp(58),1f))
        bottom.addView(nav("مورد علاقه","☆",false){Toast.makeText(this,"یادداشت‌های مورد علاقه در این بخش قرار می‌گیرند",Toast.LENGTH_SHORT).show()},LinearLayout.LayoutParams(0,dp(58),1f))
        bottom.addView(nav("کارها","✓",false){Toast.makeText(this,"بخش کارها",Toast.LENGTH_SHORT).show()},LinearLayout.LayoutParams(0,dp(58),1f))
        bottom.addView(nav("تنظیمات","⚙",false){showSettingsMenu()},LinearLayout.LayoutParams(0,dp(58),1f))
        root.addView(bottom)

        val add=MaterialButton(this).apply{text="＋";textSize=28f;setTextColor(Color.WHITE);backgroundTintList=android.content.res.ColorStateList.valueOf(primary);cornerRadius=dp(22);elevation=dp(8).toFloat();setOnClickListener{editNote(null)}}
        root.addView(add,LinearLayout.LayoutParams(dp(64),dp(64)).apply{gravity=Gravity.START;setMargins(dp(20),-dp(84),0,dp(20))})
        setContentView(root)
        renderList("","همه")
        search.addTextChangedListener(object:android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){renderList(s?.toString()?: "","همه")};override fun afterTextChanged(e:android.text.Editable?) {}})
    }

    private fun renderList(q:String,category:String="همه"){
        if(!::list.isInitialized)return
        list.removeAllViews()
        val filtered=notes.filter{n->
            val catOk=category=="همه"||n.category==category||(category=="فایل‌ها"&&n.blocks.any{it is ContentBlock.Pdf})
            val textOk=q.isBlank()||n.title.contains(q,true)||n.blocks.filterIsInstance<ContentBlock.Text>().any{it.text.contains(q,true)}
            catOk&&textOk
        }
        val grid=android.widget.GridLayout(this).apply{columnCount=if(resources.configuration.screenWidthDp>=600)3 else 2}
        val surface=if(darkMode)Color.rgb(24,29,42) else Color.WHITE
        val textColor=if(darkMode)Color.rgb(245,247,252) else Color.rgb(25,32,52)
        val subColor=if(darkMode)Color.rgb(166,176,197) else Color.rgb(104,114,136)
        val accents=listOf(Color.rgb(238,233,255),Color.rgb(232,246,240),Color.rgb(255,243,218),Color.rgb(232,242,255),Color.rgb(252,231,238))
        filtered.forEachIndexed{idx,n->
            val card=MaterialCardView(this).apply{radius=dp(22).toFloat();cardElevation=dp(2).toFloat();setCardBackgroundColor(surface);strokeWidth=0}
            val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(14),dp(14),dp(12));layoutDirection=View.LAYOUT_DIRECTION_RTL}
            val accent=View(this).apply{background=rounded(accents[idx%accents.size],6f)}
            box.addView(accent,LinearLayout.LayoutParams(-1,dp(5)).apply{setMargins(0,0,0,dp(10))})
            val head=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            head.addView(TextView(this).apply{text=n.title.ifBlank{"بدون عنوان"};textSize=16f;typeface=Typeface.DEFAULT_BOLD;setTextColor(textColor);maxLines=1;ellipsize=android.text.TextUtils.TruncateAt.END},LinearLayout.LayoutParams(0,-2,1f))
            if(n.pinned)head.addView(TextView(this).apply{text="★";textSize=15f;setTextColor(Color.rgb(238,174,42));gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(24),dp(28)))
            box.addView(head)
            val preview=n.blocks.filterIsInstance<ContentBlock.Text>().firstOrNull()?.text.orEmpty().ifBlank{when{n.blocks.any{it is ContentBlock.Pdf}->"📄 فایل PDF";n.blocks.any{it is ContentBlock.Image}->"🖼️ تصویر";n.blocks.any{it is ContentBlock.Audio}->"🎙️ فایل صوتی";n.blocks.any{it is ContentBlock.Video}->"🎬 ویدیو";else->"یادداشت بدون متن"}}
            box.addView(TextView(this).apply{text=preview.take(85);textSize=12f;setTextColor(subColor);maxLines=3;setPadding(0,dp(6),0,dp(10))})
            val meta=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            meta.addView(TextView(this).apply{text=n.category;if(text.isNotBlank()){background=rounded(accents[idx%accents.size],10f);setPadding(dp(8),dp(3),dp(8),dp(3))};textSize=10f;setTextColor(textColor)},LinearLayout.LayoutParams(0,-2,1f))
            val date=java.text.SimpleDateFormat("HH:mm • MM/dd",Locale.getDefault()).format(Date(n.id))
            meta.addView(TextView(this).apply{text=date;textSize=10f;setTextColor(subColor)})
            box.addView(meta)
            card.addView(box)
            card.setOnClickListener{editNote(n)}
            card.setOnLongClickListener{showNoteActions(n);true}
            grid.addView(card,android.widget.GridLayout.LayoutParams().apply{width=0;height=dp(172);columnSpec=android.widget.GridLayout.spec(idx%grid.columnCount,1f);rowSpec=android.widget.GridLayout.spec(idx/grid.columnCount);setMargins(dp(5),dp(5),dp(5),dp(5))})
        }
        if(filtered.isEmpty()){
            val empty=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(20),dp(70),dp(20),dp(50))}
            empty.addView(TextView(this).apply{text="✦";textSize=44f;gravity=Gravity.CENTER;setTextColor(Color.rgb(110,96,220))})
            empty.addView(TextView(this).apply{text="هنوز یادداشتی ندارید";textSize=18f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(textColor)})
            empty.addView(TextView(this).apply{text="برای شروع، روی دکمه + بزنید";textSize=13f;gravity=Gravity.CENTER;setTextColor(subColor);setPadding(0,dp(5),0,0)})
            grid.addView(empty,android.widget.GridLayout.LayoutParams().apply{columnSpec=android.widget.GridLayout.spec(0,grid.columnCount);width=-1})
        }
        list.addView(grid,LinearLayout.LayoutParams(-1,-2))
    }

    private fun showNoteActions(n:Note){
        val items=arrayOf(if(n.pinned)"برداشتن سنجاق" else "سنجاق کردن","انتقال برای دیگران","حذف")
        AlertDialog.Builder(this).setTitle(n.title.ifBlank{"یادداشت"}).setItems(items){_,which->when(which){0->{n.pinned=!n.pinned;store.save(this,n);showList()};1->{val i=Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_TEXT,buildNoteText(n,n.title,n.category))};startActivity(Intent.createChooser(i,"ارسال یادداشت با..."))};2->{n.deletedAt=System.currentTimeMillis();store.save(this,n);showList()}}}.show()
    }

    private fun showSettingsMenu(){
        val items=arrayOf("🌙  حالت شب","☁  پشتیبان‌گیری","↥  بازیابی","🗑  سطل زباله","🔒  قفل برنامه")
        AlertDialog.Builder(this).setTitle("تنظیمات یادداشت").setItems(items){_,which->when(which){0->{val d=!getSharedPreferences("ui",0).getBoolean("dark",false);getSharedPreferences("ui",0).edit().putBoolean("dark",d).apply();recreate()};1->exportBackup();2->{val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="application/json";addCategory(Intent.CATEGORY_OPENABLE)};startActivityForResult(i,909)};3->showTrash();4->showLockSettings()}}.show()
    }

    private fun editNote(existing:Note?){
        editingNote=existing
        val note=existing?:Note(System.currentTimeMillis(),"",mutableListOf(ContentBlock.Text("")),null,"یک‌بار","شخصی")
        val bg=if(darkMode)Color.rgb(12,16,25) else Color.rgb(246,247,251)
        val surface=if(darkMode)Color.rgb(24,29,42) else Color.WHITE
        val textColor=if(darkMode)Color.rgb(245,247,252) else Color.rgb(25,32,52)
        val subColor=if(darkMode)Color.rgb(166,176,197) else Color.rgb(104,114,136)
        val primary=Color.rgb(92,78,220)
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(bg);layoutDirection=View.LAYOUT_DIRECTION_RTL}
        val bar=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),dp(12),dp(14),dp(8))}
        val back=TextView(this).apply{text="‹";textSize=34f;gravity=Gravity.CENTER;setTextColor(textColor);setOnClickListener{showList()}}
        bar.addView(back,LinearLayout.LayoutParams(dp(48),dp(48)))
        bar.addView(TextView(this).apply{text=if(existing==null)"یادداشت جدید" else "ویرایش یادداشت";textSize=21f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(textColor)},LinearLayout.LayoutParams(0,-2,1f))
        val saveTop=TextView(this).apply{text="✓";textSize=25f;gravity=Gravity.CENTER;setTextColor(primary)}
        bar.addView(saveTop,LinearLayout.LayoutParams(dp(48),dp(48)))
        root.addView(bar)

        val titleWrap=TextInputLayout(this).apply{hint="عنوان یادداشت";boxBackgroundMode=TextInputLayout.BOX_BACKGROUND_OUTLINE;boxCornerRadiusTopStart=dp(16).toFloat();boxCornerRadiusTopEnd=dp(16).toFloat();boxCornerRadiusBottomStart=dp(16).toFloat();boxCornerRadiusBottomEnd=dp(16).toFloat()}
        val title=TextInputEditText(this).apply{setText(note.title);textSize=18f;setTextColor(textColor);setHintTextColor(subColor);isSingleLine=true}
        titleWrap.addView(title,TextInputLayout.LayoutParams(-1,dp(58)));root.addView(titleWrap,LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(16),0,dp(16),dp(8))})
        val cats=ChipGroup(this).apply{isSingleLine=true;chipSpacingHorizontal=dp(6);setPadding(dp(14),0,dp(14),dp(6))}
        val catNames=listOf("شخصی","کار","کلاس","دانشگاه")
        catNames.forEach{cat->val c=Chip(this).apply{text=cat;isCheckable=true;isChecked=note.category==cat;textSize=12f};cats.addView(c)}
        root.addView(cats,LinearLayout.LayoutParams(-1,dp(48)))

        val scroll=ScrollView(this).apply{clipToPadding=false}
        blocksBox=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(8),dp(16),dp(12))}
        scroll.addView(blocksBox);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))

        fun addText(initial:String=""){val e=TextInputEditText(this).apply{hint="متن یادداشت را اینجا بنویسید…";setText(initial);gravity=Gravity.TOP;minLines=5;textSize=16f;setTextColor(textColor);setHintTextColor(subColor);setPadding(dp(16),dp(14),dp(16),dp(14));background=rounded(surface,18f)};blocksBox.addView(e,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(10))})}
        fun addImage(uri:String){val img=ImageView(this).apply{tag=uri;setImageURI(Uri.parse(uri));adjustViewBounds=true;minimumHeight=180;scaleType=ImageView.ScaleType.CENTER_CROP;background=rounded(surface,18f)};blocksBox.addView(img,LinearLayout.LayoutParams(-1,dp(230)).apply{setMargins(0,0,0,dp(10))})}
        fun addVideo(uri:String){val v=VideoView(this).apply{tag=uri;setVideoURI(Uri.parse(uri));setMediaController(android.widget.MediaController(this@MainActivity));background=rounded(surface,18f)};blocksBox.addView(v,LinearLayout.LayoutParams(-1,dp(250)).apply{setMargins(0,0,0,dp(10))})}
        fun addChecklist(items:MutableList<CheckItem>){val box=MaterialCardView(this).apply{radius=dp(18).toFloat();setCardBackgroundColor(surface)};val inner=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(10),dp(14),dp(10))};items.forEach{item->inner.addView(CheckBox(this).apply{text=item.text;isChecked=item.checked;textSize=15f;setTextColor(textColor)})};inner.addView(MaterialButton(this).apply{text="＋ افزودن مورد";setOnClickListener{inner.addView(CheckBox(this@MainActivity).apply{text="مورد جدید";textSize=15f;setTextColor(textColor)})}});box.addView(inner);box.tag=items;blocksBox.addView(box,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(10))})}
        fun addAudio(path:String){val b=MaterialCardView(this).apply{radius=dp(18).toFloat();setCardBackgroundColor(surface);tag=path};val t=TextView(this).apply{text="▶  پخش صدای یادداشت\n🎙  فایل صوتی";textSize=14f;setTextColor(textColor);setPadding(dp(16),dp(12),dp(16),dp(12))};b.addView(t);b.setOnClickListener{try{activeAudio?.release();activeAudio=MediaPlayer().apply{setDataSource(path);prepare();start();setOnCompletionListener{release()}}}catch(e:Exception){Toast.makeText(this@MainActivity,"فایل صوتی پیدا نشد",Toast.LENGTH_SHORT).show()}};blocksBox.addView(b,LinearLayout.LayoutParams(-1,dp(76)).apply{setMargins(0,0,0,dp(10))})}
        fun addPdf(uri:String,name:String){val box=MaterialCardView(this).apply{radius=dp(18).toFloat();setCardBackgroundColor(surface);tag=uri};val t=TextView(this).apply{id=android.R.id.text1;text="📄  $name";textSize=14f;setTextColor(textColor);setPadding(dp(16),dp(14),dp(16),dp(14))};box.addView(t);box.setOnClickListener{try{startActivity(Intent(Intent.ACTION_VIEW).apply{setDataAndType(Uri.parse(uri),"application/pdf");addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)})}catch(_:Exception){Toast.makeText(this@MainActivity,"برنامه‌ای برای باز کردن PDF پیدا نشد",Toast.LENGTH_SHORT).show()}};blocksBox.addView(box,LinearLayout.LayoutParams(-1,dp(68)).apply{setMargins(0,0,0,dp(10))})}
        fun addDrawing(path:String){val img=ImageView(this).apply{tag=path;setImageURI(Uri.fromFile(File(path)));adjustViewBounds=true;scaleType=ImageView.ScaleType.FIT_CENTER;background=rounded(surface,18f)};blocksBox.addView(img,LinearLayout.LayoutParams(-1,dp(250)).apply{setMargins(0,0,0,dp(10))})}
        fun addMap(map:ContentBlock.MapBlock){val web=android.webkit.WebView(this).apply{tag=map;settings.javaScriptEnabled=true;settings.domStorageEnabled=true;settings.loadWithOverviewMode=true;settings.useWideViewPort=true};val lat=map.latitude;val lon=map.longitude;val label=android.text.TextUtils.htmlEncode(map.label);val html="""<!doctype html><html><head><meta name=viewport content=\"width=device-width,initial-scale=1\"><link rel=\"stylesheet\" href=\"https://unpkg.com/leaflet@1.9.4/dist/leaflet.css\"/><script src=\"https://unpkg.com/leaflet@1.9.4/dist/leaflet.js\"></script><style>html,body,#map{height:100%;margin:0}.label{font-family:sans-serif;direction:rtl}</style></head><body><div id=map></div><script>var m=L.map('map').setView([$lat,$lon],15);L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap'}).addTo(m);L.marker([$lat,$lon]).addTo(m).bindPopup('<span class=label>$label</span>').openPopup();</script></body></html>""";web.loadDataWithBaseURL("https://www.openstreetmap.org/",html,"text/html","UTF-8",null);blocksBox.addView(web,LinearLayout.LayoutParams(-1,dp(250)).apply{setMargins(0,0,0,dp(10))})}
        note.blocks.forEach{b->when(b){is ContentBlock.Text->addText(b.text);is ContentBlock.Image->addImage(b.uri);is ContentBlock.Video->addVideo(b.uri);is ContentBlock.Audio->addAudio(b.path);is ContentBlock.Pdf->addPdf(b.uri,b.name);is ContentBlock.Checklist->addChecklist(b.items);is ContentBlock.Drawing->addDrawing(b.path);is ContentBlock.MapBlock->addMap(b)}}
        if(blocksBox.childCount==0)addText()
        val pendingM=getSharedPreferences("pending_media",0);val pendingType=pendingM.getString("type",null);val pendingUri=pendingM.getString("uri",null);if(pendingType!=null&&pendingUri!=null){if(pendingType=="image")addImage(pendingUri)else if(pendingType=="video")addVideo(pendingUri);pendingM.edit().clear().apply()}
        val pendingP=getSharedPreferences("pending_pdf",0).getString("uri",null);if(pendingP!=null){addPdf(pendingP,getSharedPreferences("pending_pdf",0).getString("name","فایل PDF")?:"فایل PDF");getSharedPreferences("pending_pdf",0).edit().clear().apply()}
        val pendingA=getSharedPreferences("pending_audio",0).getString("path",null);if(pendingA!=null){addAudio(pendingA);getSharedPreferences("pending_audio",0).edit().clear().apply()}

        val toolsTitle=TextView(this).apply{text="ابزارهای یادداشت";textSize=14f;typeface=Typeface.DEFAULT_BOLD;setTextColor(textColor);setPadding(dp(18),dp(8),dp(18),dp(6))};root.addView(toolsTitle)
        val tools=GridLayout(this).apply{columnCount=4;setPadding(dp(12),0,dp(12),dp(8))}
        fun tool(label:String,icon:String,action:()->Unit){val b=MaterialCardView(this).apply{radius=dp(18).toFloat();setCardBackgroundColor(surface);setOnClickListener{action()};cardElevation=dp(1).toFloat()};val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(4),dp(10),dp(4),dp(8))};box.addView(TextView(this).apply{text=icon;textSize=22f;gravity=Gravity.CENTER});box.addView(TextView(this).apply{text=label;textSize=10f;gravity=Gravity.CENTER;setTextColor(textColor);maxLines=1});b.addView(box);tools.addView(b,GridLayout.LayoutParams().apply{width=0;height=dp(78);columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);setMargins(dp(4),dp(4),dp(4),dp(4))})}
        tool("عکس","▧"){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="image/*";addCategory(Intent.CATEGORY_OPENABLE);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)},101)}
        tool("ویدیو","▶"){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="video/*";addCategory(Intent.CATEGORY_OPENABLE);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)},102)}
        tool("صدا","●"){if(recorder==null)startRecording(note.id,null)else stopRecording(null)}
        tool("گفتار به متن","✦"){try{startActivityForResult(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{putExtra(RecognizerIntent.EXTRA_LANGUAGE,"fa-IR");putExtra(RecognizerIntent.EXTRA_PROMPT,"صحبت کنید")},speechCode)}catch(_:Exception){Toast.makeText(this,"تشخیص گفتار در دسترس نیست",Toast.LENGTH_SHORT).show()}}
        tool("چک‌لیست","☑"){addChecklist(mutableListOf(CheckItem("مورد جدید")))}
        tool("نقاشی","✎"){showDrawingEditor{path->addDrawing(path)}}
        tool("نقشه","⌖"){showMapDialog{m->addMap(m)}}
        tool("PDF","▤"){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="application/pdf";addCategory(Intent.CATEGORY_OPENABLE);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)},103)}
        root.addView(tools,LinearLayout.LayoutParams(-1,dp(92)))
        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(dp(14),0,dp(14),dp(14))}
        fun action(label:String,icon:String,weight:Float,click:()->Unit){val b=MaterialButton(this).apply{text="$icon  $label";textSize=11f;cornerRadius=dp(15);setOnClickListener{click()};backgroundTintList=android.content.res.ColorStateList.valueOf(surface)};actions.addView(b,LinearLayout.LayoutParams(0,dp(50),weight).apply{setMargins(dp(3),0,dp(3),0)})}
        action("اشتراک","↗",1f){val text=buildTextFromEditor(blocksBox,title.text.toString(),cats.checkedChipIds.firstOrNull()?.let{(cats.findViewById(it) as Chip).text.toString()}?:note.category);startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_TEXT,text)},"ارسال یادداشت با..."))}
        action("چاپ","▣",1f){val text=buildTextFromEditor(blocksBox,title.text.toString(),note.category);printNote(title.text.toString().ifBlank{"یادداشت"},text)}
        action("PDF","▤",1f){val t=title.text.toString().ifBlank{"یادداشت"};createAndSharePdf(t,buildTextFromEditor(blocksBox,t,note.category))}
        root.addView(actions)
        val save=MaterialButton(this).apply{text="ذخیره یادداشت";textSize=15f;cornerRadius=dp(18);backgroundTintList=android.content.res.ColorStateList.valueOf(primary);setTextColor(Color.WHITE)}
        root.addView(save,LinearLayout.LayoutParams(-1,dp(56)).apply{setMargins(dp(16),0,dp(16),dp(14))})
        setContentView(root)
        fun doSave(){
            note.title=title.text?.toString()?: "";note.category=(cats.checkedChipIds.firstOrNull()?.let{(cats.findViewById(it) as Chip).text.toString()})?:"شخصی";note.blocks.clear()
            for(i in 0 until blocksBox.childCount){when(val v=blocksBox.getChildAt(i)){is TextInputEditText->note.blocks.add(ContentBlock.Text(v.text?.toString()?: ""));is ImageView->{val path=v.tag as? String;if(path!=null){if(path.endsWith(".png",true)&&File(path).parentFile?.name=="drawings")note.blocks.add(ContentBlock.Drawing(path))else note.blocks.add(ContentBlock.Image(path))};is VideoView->{(v.tag as? String)?.let{note.blocks.add(ContentBlock.Video(it))}};is android.webkit.WebView->{(v.tag as? ContentBlock.MapBlock)?.let{note.blocks.add(it)}};is MaterialCardView->{val tag=v.tag as? String;if(tag!=null){val nm=v.findViewById<TextView>(android.R.id.text1)?.text?.toString()?.removePrefix("📄  ")?:"فایل PDF";note.blocks.add(ContentBlock.Pdf(tag,nm))}else{val inner=v.getChildAt(0) as? LinearLayout;if(inner!=null){val items=mutableListOf<CheckItem>();for(j in 0 until inner.childCount){val c=inner.getChildAt(j);if(c is CheckBox)items.add(CheckItem(c.text.toString(),c.isChecked))};if(items.isNotEmpty())note.blocks.add(ContentBlock.Checklist(items))}}}}}
            getSharedPreferences("pending_audio",0).getString("path",null)?.let { path -> note.blocks.add(ContentBlock.Audio(path)); getSharedPreferences("pending_audio",0).edit().clear().apply() }
            store.save(this,note);Toast.makeText(this,"یادداشت ذخیره شد",Toast.LENGTH_SHORT).show();showList()
        }
        save.setOnClickListener{doSave()};saveTop.setOnClickListener{doSave()}
    }

    private fun showMapDialog(onAdd: (ContentBlock.MapBlock) -> Unit) {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,8,24,8);layoutDirection=View.LAYOUT_DIRECTION_RTL}
        val label=EditText(this).apply{hint="نام مکان (اختیاری)"}
        val lat=EditText(this).apply{hint="عرض جغرافیایی مثال: 52.3676";inputType=android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL or android.text.InputType.TYPE_NUMBER_FLAG_SIGNED}
        val lon=EditText(this).apply{hint="طول جغرافیایی مثال: 4.9041";inputType=android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL or android.text.InputType.TYPE_NUMBER_FLAG_SIGNED}
        box.addView(label);box.addView(lat);box.addView(lon)
        AlertDialog.Builder(this).setTitle("🗺️ افزودن نقشه").setMessage("مختصات را وارد کنید. نقشه داخل خود یادداشت نمایش داده می‌شود.").setView(box).setPositiveButton("افزودن"){_,_->
            val la=lat.text.toString().replace(",",".").toDoubleOrNull(); val lo=lon.text.toString().replace(",",".").toDoubleOrNull()
            if(la==null||lo==null||la !in -90.0..90.0||lo !in -180.0..180.0){Toast.makeText(this,"مختصات نامعتبر است",Toast.LENGTH_SHORT).show();return@setPositiveButton}
            onAdd(ContentBlock.MapBlock(la,lo,label.text.toString()))
        }.setNegativeButton("انصراف",null).show()
    }

    private fun showDrawingEditor(onAdd: (String) -> Unit) {
        val draw=SketchView(this)
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(8,8,8,8);layoutDirection=View.LAYOUT_DIRECTION_RTL}
        root.addView(draw,LinearLayout.LayoutParams(-1,0,1f))
        val tools=LinearLayout(this)
        fun sym(s:String)=Button(this).apply{text=s;setOnClickListener{draw.addSymbol(s)}}
        tools.addView(Button(this).apply{text="↩️";setOnClickListener{draw.undo()}})
        tools.addView(Button(this).apply{text="🧹";setOnClickListener{draw.clear()}})
        listOf("→","←","↔","✓","✗","○","□","△","◇","★","+","−","×","÷","⚠").forEach{tools.addView(sym(it))}
        root.addView(ScrollView(this).apply{addView(tools)},LinearLayout.LayoutParams(-1,64))
        AlertDialog.Builder(this).setTitle("🎨 طراحی و نمادها").setView(root).setPositiveButton("💾 افزودن به یادداشت"){_,_->
            val dir=File(filesDir,"drawings");dir.mkdirs(); val file=File(dir,"drawing_${System.currentTimeMillis()}.png")
            try{draw.save(file);onAdd(file.absolutePath)}catch(e:Exception){Toast.makeText(this,"ذخیره طرح انجام نشد",Toast.LENGTH_SHORT).show()}
        }.setNegativeButton("انصراف",null).show()
    }

    private class SketchView(context: Context): View(context) {
        private val paths=mutableListOf<Pair<Path,Paint>>(); private val undone=mutableListOf<Pair<Path,Paint>>(); private var current:Path?=null
        private val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.BLACK;style=Paint.Style.STROKE;strokeWidth=7f;strokeCap=Paint.Cap.ROUND}
        private val symbols=mutableListOf<Pair<String,FloatArray>>()
        init{setBackgroundColor(Color.WHITE)}
        override fun onDraw(c:Canvas){super.onDraw(c);paths.forEach{c.drawPath(it.first,it.second)};symbols.forEach{(s,p)->val tp=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.BLACK;textSize=72f;style=Paint.Style.FILL};c.drawText(s,p[0],p[1],tp)} }
        override fun onTouchEvent(e:android.view.MotionEvent):Boolean{when(e.action){MotionEvent.ACTION_DOWN->{current=Path().apply{moveTo(e.x,e.y)};paths.add(current!! to Paint(paint));undone.clear();invalidate();return true};MotionEvent.ACTION_MOVE->{current?.lineTo(e.x,e.y);invalidate();return true};MotionEvent.ACTION_UP->{current=null;return true}};return true}
        fun undo(){if(paths.isNotEmpty())undone.add(paths.removeAt(paths.lastIndex));invalidate()}
        fun clear(){paths.clear();symbols.clear();undone.clear();invalidate()}
        fun addSymbol(s:String){symbols.add(s to floatArrayOf(width/2f,height/2f));invalidate()}
        fun save(file:File){val b=Bitmap.createBitmap(width.coerceAtLeast(1),height.coerceAtLeast(1),Bitmap.Config.ARGB_8888);val c=Canvas(b);c.drawColor(Color.WHITE);draw(c);file.outputStream().use{b.compress(Bitmap.CompressFormat.PNG,100,it)};b.recycle()}
    }

    private fun buildTextFromEditor(box: LinearLayout, title: String, category: String): String {
        val sb = StringBuilder()
        sb.append(title.ifBlank { "یادداشت" }).append("\n")
        if (category.isNotBlank()) sb.append("دسته‌بندی: ").append(category).append("\n")
        sb.append("\n")
        for (i in 0 until box.childCount) {
            when (val v = box.getChildAt(i)) {
                is EditText -> if (v.text.isNotBlank()) sb.append(v.text).append("\n\n")
                is ImageView -> {
                    val path=v.tag as? String
                    sb.append(if(path?.endsWith(".png", true)==true && File(path).parentFile?.name=="drawings") "[طرح دستی پیوست شده]" else "[عکس پیوست شده]").append("\n\n")
                }
                is VideoView -> sb.append("[فیلم پیوست شده]\n\n")
                is android.webkit.WebView -> {
                    val m=v.tag as? ContentBlock.MapBlock
                    if(m!=null) sb.append("[نقشه: ").append(m.label.ifBlank { "موقعیت ذخیره‌شده" }).append(" — ").append(m.latitude).append(", ").append(m.longitude).append("]\n\n")
                }
                is Button -> if (v.tag is String) sb.append("[فایل صوتی پیوست شده]\n\n")
                is LinearLayout -> for (j in 0 until v.childCount) { val c=v.getChildAt(j); if(c is CheckBox) sb.append(if(c.isChecked) "☑ " else "☐ ").append(c.text).append("\n") }
            }
        }
        return sb.toString().trim()
    }

    private fun buildNoteText(note: Note, title: String, category: String): String {
        val sb = StringBuilder()
        sb.append(title.ifBlank { "یادداشت" }).append("\n")
        if (category.isNotBlank()) sb.append("دسته‌بندی: ").append(category).append("\n")
        sb.append("\n")
        note.blocks.forEach { block ->
            when (block) {
                is ContentBlock.Text -> if (block.text.isNotBlank()) sb.append(block.text).append("\n\n")
                is ContentBlock.Image -> sb.append("[عکس پیوست شده]\n\n")
                is ContentBlock.Video -> sb.append("[فیلم پیوست شده]\n\n")
                is ContentBlock.Audio -> sb.append("[فایل صوتی پیوست شده]\n\n")
                is ContentBlock.Pdf -> sb.append("[فایل PDF: ").append(block.name).append("]\n\n")
                is ContentBlock.Checklist -> block.items.forEach { item -> sb.append(if(item.checked) "☑ " else "☐ ").append(item.text).append("\n") }
                is ContentBlock.Drawing -> sb.append("[طرح دستی پیوست شده]\n\n")
                is ContentBlock.MapBlock -> sb.append("[نقشه: ").append(block.label.ifBlank { "موقعیت ذخیره‌شده" }).append(" — ").append(block.latitude).append(", ").append(block.longitude).append("]\n\n")
            }
        }
        return sb.toString().trim()
    }

    private fun exportBackup() {
        try {
            val dir=File(cacheDir,"backup"); dir.mkdirs()
            val file=File(dir,"yaddasht-backup-${System.currentTimeMillis()}.json")
            file.writeText(NoteStore.exportJson(this), Charsets.UTF_8)
            val uri=FileProvider.getUriForFile(this,"${packageName}.fileprovider",file)
            val send=Intent(Intent.ACTION_SEND).apply {
                type="application/json"
                putExtra(Intent.EXTRA_SUBJECT,"پشتیبان یادداشت‌ها")
                putExtra(Intent.EXTRA_STREAM,uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(send,"ذخیره یا ارسال پشتیبان"))
        } catch(e:Exception) {
            Toast.makeText(this,"ساخت پشتیبان انجام نشد",Toast.LENGTH_SHORT).show()
        }
    }

    private fun printNote(title: String, text: String) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.KITKAT) {
            Toast.makeText(this, "قابلیت چاپ به نسخه جدیدتر اندروید نیاز دارد", Toast.LENGTH_SHORT).show()
            return
        }
        val printManager = getSystemService(Context.PRINT_SERVICE) as android.print.PrintManager
        val webView = android.webkit.WebView(this)
        webView.settings.defaultTextEncodingName = "UTF-8"
        val escaped = android.text.TextUtils.htmlEncode(text).replace("\n", "<br>")
        val html = """
            <html><head><meta charset="utf-8"><style>
            body{font-family:sans-serif;direction:rtl;text-align:right;padding:24px;font-size:16px;line-height:1.8}
            h1{font-size:24px}
            </style></head><body><h1>${android.text.TextUtils.htmlEncode(title)}</h1><p>$escaped</p></body></html>
        """.trimIndent()
        webView.webViewClient = object : android.webkit.WebViewClient() {
            override fun onPageFinished(view: android.webkit.WebView?, url: String?) {
                val adapter = webView.createPrintDocumentAdapter("یادداشت - $title")
                printManager.print(
                    "یادداشت - $title",
                    adapter,
                    android.print.PrintAttributes.Builder()
                        .setMediaSize(android.print.PrintAttributes.MediaSize.ISO_A4)
                        .setMinMargins(android.print.PrintAttributes.Margins.NO_MARGINS)
                        .build()
                )
            }
        }
        webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
    }

    private fun createAndSharePdf(title: String, text: String) {
        try {
            val dir = File(cacheDir, "pdf")
            dir.mkdirs()
            val safe = title.replace(Regex("[^\\p{L}\\p{N}_-]+"), "_").take(40).ifBlank { "yaddasht" }
            val file = File(dir, "$safe-${System.currentTimeMillis()}.pdf")

            val document = PdfDocument()
            val pageWidth = 595
            val pageHeight = 842
            val margin = 42
            val textWidth = pageWidth - margin * 2

            val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = 14f
                typeface = Typeface.create("sans", Typeface.NORMAL)
                color = android.graphics.Color.BLACK
            }
            val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = 22f
                typeface = Typeface.create("sans", Typeface.BOLD)
                color = android.graphics.Color.BLACK
            }

            val titleLayout = StaticLayout.Builder.obtain(
                title, 0, title.length, titlePaint, textWidth
            ).setAlignment(Layout.Alignment.ALIGN_NORMAL)
             .setIncludePad(true)
             .setTextDirection(android.text.TextDirectionHeuristics.FIRSTSTRONG_RTL)
             .build()

            val body = text.removePrefix(title).trim().ifBlank { "محتوایی برای نمایش وجود ندارد." }
            val bodyLayout = StaticLayout.Builder.obtain(
                body, 0, body.length, paint, textWidth
            ).setAlignment(Layout.Alignment.ALIGN_NORMAL)
             .setIncludePad(true)
             .setTextDirection(android.text.TextDirectionHeuristics.FIRSTSTRONG_RTL)
             .build()

            var bodyOffset = 0
            var pageNumber = 1
            while (bodyOffset < bodyLayout.lineCount || pageNumber == 1) {
                val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
                val page = document.startPage(pageInfo)
                val canvas = page.canvas
                canvas.drawColor(android.graphics.Color.WHITE)

                canvas.save()
                canvas.translate(margin.toFloat(), margin.toFloat())
                if (pageNumber == 1) {
                    titleLayout.draw(canvas)
                    canvas.translate(0f, (titleLayout.height + 18).toFloat())
                }

                val available = pageHeight - margin * 2 - (if (pageNumber == 1) titleLayout.height + 18 else 0)
                val startLine = bodyLayout.getLineForOffset(bodyOffset)
                var endLine = startLine
                var used = 0
                while (endLine < bodyLayout.lineCount) {
                    val h = bodyLayout.getLineBottom(endLine) - bodyLayout.getLineTop(endLine)
                    if (used + h > available) break
                    used += h
                    endLine++
                }
                if (endLine == startLine) endLine = (startLine + 1).coerceAtMost(bodyLayout.lineCount)
                val endOffset = bodyLayout.getLineEnd(endLine - 1).coerceAtLeast(bodyOffset)

                canvas.save()
                canvas.clipRect(0, 0, textWidth, available)
                canvas.translate(0f, -bodyLayout.getLineTop(startLine).toFloat())
                bodyLayout.draw(canvas)
                canvas.restore()
                canvas.restore()

                document.finishPage(page)
                bodyOffset = endOffset
                pageNumber++
                if (bodyOffset >= bodyLayout.text.length) break
            }

            file.outputStream().use { document.writeTo(it) }
            document.close()

            val uri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", file)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_SUBJECT, title)
                putExtra(Intent.EXTRA_TEXT, "فایل PDF یادداشت: $title")
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(send, "ارسال PDF با..."))
        } catch (e: Exception) {
            Toast.makeText(this, "ساخت PDF انجام نشد: ${e.message ?: "خطای ناشناخته"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun startRecording(noteId:Long, button:Button?){
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.RECORD_AUDIO),73); return
        }
        val dir=File(filesDir,"audio"); dir.mkdirs()
        recordingPath=File(dir,"note_${noteId}_${System.currentTimeMillis()}.m4a").absolutePath
        recorder=MediaRecorder(this).apply{
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setOutputFile(recordingPath)
            prepare(); start()
        }
        button?.text="⏹️ توقف ضبط"
        Toast.makeText(this,"در حال ضبط صدا...",Toast.LENGTH_SHORT).show()
    }
    private fun stopRecording(button:Button?){
        try{recorder?.stop()}catch(_:Exception){}
        recorder?.release(); recorder=null
        val path=recordingPath
        if(path!=null){
            // add to current editor by placing a button at the end is handled through a lightweight event.
            Toast.makeText(this,"ضبط صدا انجام شد؛ هنگام ذخیره به یادداشت اضافه می‌شود.",Toast.LENGTH_SHORT).show()
            val current=NoteStore.loadAll(this).firstOrNull { path.contains("note_${it.id}_") }
            // For new notes, persist the audio as a standalone attachment marker in a tiny preference.
            getSharedPreferences("pending_audio",0).edit().putString("path",path).apply()
        }
        button?.text="🎙️ ضبط صدای جدید"
    }

    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){
        super.onActivityResult(requestCode,resultCode,data)
        if(resultCode != RESULT_OK) return

        if(requestCode == speechCode) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if(!spoken.isNullOrBlank()) {
                val target = findFocusedEditText(window.decorView)
                if(target != null) {
                    val pos = target.selectionStart.coerceAtLeast(0)
                    target.text.insert(pos, spoken + " ")
                }
            }
            return
        }

        val uri=data?.data ?: return
        if(requestCode==103){
            try{contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)}catch(_:Exception){}
            val displayName = try { contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if(c.moveToFirst()) c.getString(0) else null } } catch(_:Exception){ null } ?: "فایل PDF"
            getSharedPreferences("pending_pdf",0).edit().putString("uri",uri.toString()).putString("name", displayName).apply()
            Toast.makeText(this,"PDF انتخاب شد؛ هنگام ویرایش داخل یادداشت قرار می‌گیرد.",Toast.LENGTH_SHORT).show()
            return
        }
        if(requestCode==909){
            try { val json=contentResolver.openInputStream(uri)?.bufferedReader()?.use{it.readText()} ?: ""; val count=store.importJson(this,json); Toast.makeText(this,"$count یادداشت بازیابی شد",Toast.LENGTH_LONG).show(); showList() } catch(e:Exception){Toast.makeText(this,"فایل پشتیبان نامعتبر است",Toast.LENGTH_LONG).show()}
            return
        }
        try{contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)}catch(_:Exception){}
        getSharedPreferences("pending_media",0).edit()
            .putString("type", if(requestCode==101)"image" else "video")
            .putString("uri",uri.toString()).apply()
        Toast.makeText(this,if(requestCode==101)"عکس انتخاب شد؛ دوباره وارد ویرایش یادداشت شو تا داخل آن قرار بگیرد." else "فیلم انتخاب شد؛ دوباره وارد ویرایش یادداشت شو تا داخل آن قرار بگیرد.",Toast.LENGTH_SHORT).show()
    }

    private fun showTrash() {
        val deleted = store.loadAll(this, true).filter { it.deletedAt != null }.sortedByDescending { it.deletedAt }
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,18,18,18);layoutDirection=View.LAYOUT_DIRECTION_RTL}
        box.addView(TextView(this).apply{text="🗑️ سطل زباله";textSize=26f})
        if(deleted.isEmpty()) box.addView(TextView(this).apply{text="سطل زباله خالی است.";textSize=18f})
        deleted.forEach { n ->
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
            row.addView(TextView(this).apply{text=n.title.ifBlank{"بدون عنوان"};textSize=17f},LinearLayout.LayoutParams(0,-2,1f))
            row.addView(Button(this).apply{text="♻️ بازیابی";setOnClickListener{n.deletedAt=null;store.save(this@MainActivity,n);showTrash()}})
            row.addView(Button(this).apply{text="حذف دائم";setOnClickListener{store.delete(this@MainActivity,n.id);showTrash()}})
            box.addView(row)
        }
        box.addView(Button(this).apply{text="بازگشت";setOnClickListener{showList()}})
        setContentView(ScrollView(this).apply{addView(box)})
    }

    private fun showLockSettings() {
        val prefs=getSharedPreferences("security",0)
        val has=prefs.contains("pin_hash")
        val input=EditText(this).apply{inputType=2;hint="رمز ۴ رقمی یا بیشتر"}
        val positiveText = if (has) "ذخیره" else "فعال‌سازی"
        AlertDialog.Builder(this).setTitle(if(has) "تغییر/لغو قفل" else "قفل برنامه")
            .setView(input).setPositiveButton(positiveText) { _, _ ->
                val pin=input.text.toString()
                if(pin.length>=4) prefs.edit().putString("pin_hash",sha256(pin)).apply() else if(has && pin.isBlank()) prefs.edit().remove("pin_hash").apply()
            }.setNegativeButton("انصراف",null).show()
    }

    private fun sha256(value:String):String {
        val d=java.security.MessageDigest.getInstance("SHA-256").digest(value.toByteArray(Charsets.UTF_8))
        return d.joinToString(""){"%02x".format(it)}
    }

    private fun requireUnlock():Boolean {
        val hash=getSharedPreferences("security",0).getString("pin_hash",null) ?: return true
        val input=EditText(this).apply{inputType=2;hint="رمز قفل"}
        var dialog:AlertDialog?=null
        dialog=AlertDialog.Builder(this).setTitle("🔐 قفل برنامه").setView(input).setCancelable(false)
            .setPositiveButton("ورود",null).create()
        dialog.setOnShowListener { dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener { if(sha256(input.text.toString())==hash) { dialog.dismiss(); showList() } else input.error="رمز اشتباه است" } }
        dialog.show(); return false
    }

    private fun findFocusedEditText(view: View): EditText? {
        if(view is EditText && view.hasFocus()) return view
        if(view is ViewGroup) {
            for(i in 0 until view.childCount) {
                val found = findFocusedEditText(view.getChildAt(i))
                if(found != null) return found
            }
        }
        return null
    }
}
